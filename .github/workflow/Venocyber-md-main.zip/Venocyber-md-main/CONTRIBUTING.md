### How To Contribute To Us
1. Create an Issue on Github 
2. Add you phone number or email and tell us to Contact You
3. Then Us how and why you want to contribute to this project
-----------------------------------------------------------------


# VENOCYBER MD

You can send anything via VODACOM Mpesa number 0749614269 <b>JASTIN ASHERY MTEWA</b>
