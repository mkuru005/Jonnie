# PATCH VENOCYBER ᴍᴅ ᴜᴘᴅᴀᴛᴇ 𝟷.𝟶.𝟻 ᴘᴀᴛᴄʜ
### ᴡʜᴀᴛ's ɴᴇᴡ?
-----------------------------------
1. *Session ID Not Connecting Error Fixed*

2. *Commands Taking Time Not To Respond Fixed*

3. *Fixed Error when starting with Heroku*


## Details

#### Session Id Not Connecting Fixed.
<p>We have fixed error with session id not connecting to whatsapp especially if the user has not used Asta Md before, this error occurs when the WhatsApp Account has never be connected to the baielys libary, one of the ways you could manually fix your session id is by running Asta Md on VPS and connect through the QR CODE Genrate in the terminal. We have Fixed this error so that you do not have to worry about your session id not working for your WhatsApp Account, the major cause of this problem, is the WhiskeySockets Balieys, This Problem is expected to be solved later in the future.</p>
------------


#### Commands Taking Time (or not responding) Fixed

<p>This occurs when a command buffers too long, which may cause latency, the cause of the problem is due to the platform your running your bot on, like replit, render, termux, these platforms are regarded as slow, and ineffectint platforms for running Node Js App, please keep in mind, that the platform you use will greatly impacts the bot's perfomance, regardless of our endourvous to reduce it's latency.</p>
-----------


#### Fixed Error When Starting Heroku
<p>Fixed Error in Heroku</p>
